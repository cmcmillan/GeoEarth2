This release contains the following directories/files:

jsi-1.0b1/jsi/src          - source code to the JSI library. Test code is in 
                           - the com.infomatiq.jsi.test package.
jsi-1.0b1/jsi/bin          - compiled version of jsi/src
jsi-1.0b1/jsi/lib          - the log4j-1.2.6 and trove-0.1.8 libraries are 
                             required by the JSI library. The junit-3.7.0 and
                             sil-0.43b-am1 libraries are only required by the 
                             test code.
jsi-1.0b1/jsi/tests        - test scripts
jsi-1.0b1/jsi/test-results - test results will be placed here
jsi-1.0b1/jsi/doc          - documentation
jsi-1.0b1/jsi/doc/javadoc  - javadoc documentation
jsi-1.0b1/jsi/build.xml    - ANT build script. See BUILD.txt.
